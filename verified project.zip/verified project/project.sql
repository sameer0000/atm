-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2019 at 01:04 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'saikiran@admin.com', 'saikiran'),
(2, 'admin@admin.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('558922117fcef', '5589221195248'),
('55892211e44d5', '55892211f1fa7'),
('558922894c453', '558922895ea0a'),
('558922899ccaa', '55892289aa7cf'),
('558923538f48d', '558923539a46c'),
('55892353f05c4', '55892354051be'),
('5cf8e78788d09', '5cf8e78864349'),
('5cf8e788d53fc', '5cf8e788dd4e6'),
('5cf8e7896e3ad', '5cf8e789aac7b'),
('5cf8e78a44bcc', '5cf8e78a51ebf'),
('5cf8e78aa85a4', '5cf8e78abf4d9'),
('5cf8e78aed344', '5cf8e78b00636'),
('5cf8e78b36972', '5cf8e78b4099d'),
('5cf8e78b55992', '5cf8e78b5a7b3'),
('5cf8e78b7ca9b', '5cf8e78b83414'),
('5cf8e78b9e99b', '5cf8e78ba9195'),
('5cf8e78bcdb8e', '5cf8e78bd3d37'),
('5cf8e78bf40df', '5cf8e78c08371'),
('5cf8e78c3ee7d', '5cf8e78c52aea'),
('5cf8e78c72e92', '5cf8e78c73662'),
('5cf8e78c8b91f', '5cf8e78c8c8c0'),
('5cf8e78ca3fc5', '5cf8e78cb0ae8'),
('5cf8e78cce77f', '5cf8e78ccef4f'),
('5cf8e78cefeaf', '5cf8e78d01a30'),
('5cf8e78d18966', '5cf8e78d28369'),
('5cf8e78d53eac', '5cf8e78d57944'),
('5cf8e78da670f', '5cf8e78dc3fbe'),
('5cf8e78e15ea6', '5cf8e78e1b880'),
('5cf8e78e3c7df', '5cf8e78e42989'),
('5cf8e78e5a476', '5cf8e78e5f297'),
('5cf8e78e80daf', '5cf8e78e85fb8'),
('5cf8e78e9d2d6', '5cf8e78ea347f'),
('5cf8e78eb9fcd', '5cf8e78ec055e'),
('5cf8e78ed64f3', '5cf8e78edc2b5'),
('5cf8e78f0071a', '5cf8e78f068c4'),
('5cf8e78f2ddb5', '5cf8e78f65c4a'),
('5cf8e78f89e73', '5cf8e78f8f84c'),
('5cf8e78fadcb3', '5cf8e78fb2ebc'),
('5cf8e7900ce8e', '5cf8e7900da47'),
('5cf8e790969cf', '5cf8e7909719f'),
('5cf8e790b9c57', '5cf8e790babf7'),
('5cf8e790d1745', '5cf8e790dcaf7'),
('5cf8e790f1ed4', '5cf8e790f26a4'),
('5cf8e791147e1', '5cf8e7911ad73'),
('5cf8e791460e5', '5cf8e79149796'),
('5cf8e7915d7eb', '5cf8e791635ac');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `sahi`, `wrong`, `date`) VALUES
('sunnygkp10@gmail.com', '558921841f1ec', 4, 2, 2, 0, '2015-06-23 09:31:26'),
('avantika420@gmail.com', '558921841f1ec', 4, 2, 2, 0, '2015-06-23 14:33:04'),
('avantika420@gmail.com', '5589222f16b93', 4, 2, 2, 0, '2015-06-23 14:49:39'),
('mi5@hollywood.com', '5589222f16b93', 4, 2, 2, 0, '2015-06-23 15:12:56'),
('nik1@gmail.com', '558921841f1ec', 1, 2, 1, 1, '2015-06-23 16:11:50'),
('sunnygkp10@gmail.com', '5589222f16b93', 1, 2, 1, 1, '2015-06-24 03:22:38'),
('saiushajosyula@gmail.com', '5cf8dd2dae8da', -16, 20, 6, 14, '2019-06-06 10:20:26'),
('kiransai8811@gmail.com', '5cf8dd2dae8da', -12, 20, 7, 13, '2019-06-06 10:55:42'),
('sairam@gmail.com', '5cf8dd2dae8da', -16, 20, 6, 14, '2019-06-06 10:57:35');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('558922117fcef', 'echo', '5589221195248'),
('558922117fcef', 'print', '558922119525a'),
('558922117fcef', 'printf', '5589221195265'),
('558922117fcef', 'cout', '5589221195270'),
('55892211e44d5', 'int a', '55892211f1f97'),
('55892211e44d5', '$a', '55892211f1fa7'),
('55892211e44d5', 'long int a', '55892211f1fb4'),
('55892211e44d5', 'int a$', '55892211f1fbd'),
('558922894c453', 'cin>>a;', '558922895ea0a'),
('558922894c453', 'cin<<a;', '558922895ea26'),
('558922894c453', 'cout>>a;', '558922895ea34'),
('558922894c453', 'cout<a;', '558922895ea41'),
('558922899ccaa', 'cout', '55892289aa7cf'),
('558922899ccaa', 'cin', '55892289aa7df'),
('558922899ccaa', 'print', '55892289aa7eb'),
('558922899ccaa', 'printf', '55892289aa7f5'),
('558923538f48d', '255.0.0.0', '558923539a46c'),
('558923538f48d', '255.255.255.0', '558923539a480'),
('558923538f48d', '255.255.0.0', '558923539a48b'),
('558923538f48d', 'none of these', '558923539a495'),
('55892353f05c4', '192.168.1.100', '5589235405192'),
('55892353f05c4', '172.168.16.2', '55892354051a3'),
('55892353f05c4', '10.0.0.0.1', '55892354051b4'),
('55892353f05c4', '11.11.11.11', '55892354051be'),
('5cf8e78788d09', 'John joseph ', '5cf8e78863791'),
('5cf8e78788d09', 'Vanaja N.Sarna', '5cf8e78863b79'),
('5cf8e78788d09', 'Mahender Singh ', '5cf8e78863f61'),
('5cf8e78788d09', 'S Ramesh', '5cf8e78864349'),
('5cf8e788d53fc', 'Arvind Saxena', '5cf8e788dd4e6'),
('5cf8e788d53fc', 'Sudha Jain ', '5cf8e788dd8ce'),
('5cf8e788d53fc', 'Kirti Kumar ', '5cf8e788ddcb6'),
('5cf8e788d53fc', 'Omi Agrawal', '5cf8e788de09e'),
('5cf8e7896e3ad', 'Jammu & Kashmir ', '5cf8e789aa4ab'),
('5cf8e7896e3ad', 'Himachal Pradesh', '5cf8e789aa893'),
('5cf8e7896e3ad', 'Uttarakhand ', '5cf8e789aac7b'),
('5cf8e7896e3ad', 'Assam', '5cf8e789ab063'),
('5cf8e78a44bcc', 'Chennai', '5cf8e78a51ad7'),
('5cf8e78a44bcc', 'Delhi', '5cf8e78a51ebf'),
('5cf8e78a44bcc', 'Nagpur', '5cf8e78a522a8'),
('5cf8e78a44bcc', 'Kolkata', '5cf8e78a52690'),
('5cf8e78aa85a4', 'Nittoor SrinivasaRau commiittee', '5cf8e78abe921'),
('5cf8e78aa85a4', 'Tejendra Mohan Bhasin commiittee', '5cf8e78abed09'),
('5cf8e78aa85a4', 'KV Chowdary commiittee', '5cf8e78abf0f1'),
('5cf8e78aa85a4', 'K Santhanam commiittee', '5cf8e78abf4d9'),
('5cf8e78aed344', 'Union Bank of India', '5cf8e78af40a5'),
('5cf8e78aed344', 'Axis Bank', '5cf8e78b0024e'),
('5cf8e78aed344', 'Punjab National Bank', '5cf8e78b00636'),
('5cf8e78aed344', 'Bank of Baroda', '5cf8e78b00a1e'),
('5cf8e78b36972', 'Fiji', '5cf8e78b3fde4'),
('5cf8e78b36972', 'Papua New Guinea', '5cf8e78b401cc'),
('5cf8e78b36972', 'New Zealand', '5cf8e78b405b5'),
('5cf8e78b36972', 'Marshall Islands', '5cf8e78b4099d'),
('5cf8e78b55992', 'Arjun Mitra', '5cf8e78b5a3cb'),
('5cf8e78b55992', 'Ashu Khullar', '5cf8e78b5a7b3'),
('5cf8e78b55992', 'Nandish Prabhakar', '5cf8e78b5ab9b'),
('5cf8e78b55992', 'Rakesh Singh', '5cf8e78b5af83'),
('5cf8e78b7ca9b', 'Andra Pradesh', '5cf8e78b82c44'),
('5cf8e78b7ca9b', 'Odisha', '5cf8e78b8302c'),
('5cf8e78b7ca9b', 'Rajasthan', '5cf8e78b83414'),
('5cf8e78b7ca9b', 'Tamil Nadu', '5cf8e78b837fc'),
('5cf8e78b9e99b', '2024', '5cf8e78ba9195'),
('5cf8e78b9e99b', '2022', '5cf8e78ba957d'),
('5cf8e78b9e99b', '2032', '5cf8e78ba9965'),
('5cf8e78b9e99b', '2040', '5cf8e78ba9d4d'),
('5cf8e78bcdb8e', 'K.N. Vyas', '5cf8e78bd394f'),
('5cf8e78bcdb8e', 'Dr. A.K. Mohanty', '5cf8e78bd3d37'),
('5cf8e78bcdb8e', 'Abhishek Agarwal', '5cf8e78bd411f'),
('5cf8e78bcdb8e', 'Shatrughan Agrawal', '5cf8e78bd4507'),
('5cf8e78bf40df', 'Dharmendra Pradhan', '5cf8e78c07f89'),
('5cf8e78bf40df', 'Hardeep Singh Puri', '5cf8e78c08371'),
('5cf8e78bf40df', 'Piyush Goyal', '5cf8e78c08759'),
('5cf8e78bf40df', 'Prakash Javadekar', '5cf8e78c08b41'),
('5cf8e78c3ee7d', 'NASIK', '5cf8e78c5231a'),
('5cf8e78c3ee7d', ' NASIC', '5cf8e78c52702'),
('5cf8e78c3ee7d', 'NAVIC', '5cf8e78c52aea'),
('5cf8e78c3ee7d', 'NAVIK', '5cf8e78c52ed2'),
('5cf8e78c72e92', 'Chattisgarh', '5cf8e78c7327a'),
('5cf8e78c72e92', 'Telangana', '5cf8e78c73662'),
('5cf8e78c72e92', 'Kerala', '5cf8e78c73a4a'),
('5cf8e78c72e92', 'Maharashtra', '5cf8e78c73e32'),
('5cf8e78c8b91f', 'Private Sector Banks', '5cf8e78c8bd07'),
('5cf8e78c8b91f', 'Public Sector Banks', '5cf8e78c8c0ef'),
('5cf8e78c8b91f', 'Regional Rural Banks', '5cf8e78c8c4d8'),
('5cf8e78c8b91f', 'Cooperative Banks', '5cf8e78c8c8c0'),
('5cf8e78ca3fc5', 'Maharashtra', '5cf8e78cb0318'),
('5cf8e78ca3fc5', 'Madhya Pradesh', '5cf8e78cb0700'),
('5cf8e78ca3fc5', 'Andhra Pradesh', '5cf8e78cb0ae8'),
('5cf8e78ca3fc5', 'Himachal Pradesh', '5cf8e78cb0ed0'),
('5cf8e78cce77f', 'BTI Payments', '5cf8e78cceb67'),
('5cf8e78cce77f', 'Tata Communications Payment Solutions', '5cf8e78ccef4f'),
('5cf8e78cce77f', 'Muthoot Finance Limited', '5cf8e78ccf337'),
('5cf8e78cce77f', 'Prize Payments Solutions Limited', '5cf8e78ccf71f'),
('5cf8e78cefeaf', 'Darban, South Africa', '5cf8e78d00e78'),
('5cf8e78cefeaf', 'London, UK', '5cf8e78d01260'),
('5cf8e78cefeaf', 'Toronto, Canada', '5cf8e78d01648'),
('5cf8e78cefeaf', 'Gold Coast, Australia', '5cf8e78d01a30'),
('5cf8e78d18966', 'Russia', '5cf8e78d277b1'),
('5cf8e78d18966', 'China', '5cf8e78d27b99'),
('5cf8e78d18966', ' France', '5cf8e78d27f81'),
('5cf8e78d18966', 'USA', '5cf8e78d28369'),
('5cf8e78d53eac', 'Secret Super Star', '5cf8e78d5755c'),
('5cf8e78d53eac', 'Tumhari Sulu', '5cf8e78d57944'),
('5cf8e78d53eac', ' Mom', '5cf8e78d57d2c'),
('5cf8e78d53eac', 'Hindi Medium', '5cf8e78d58115'),
('5cf8e78da670f', 'John joseph ', '5cf8e78dc3406'),
('5cf8e78da670f', 'Vanaja N.Sarna', '5cf8e78dc37ee'),
('5cf8e78da670f', 'Mahender Singh ', '5cf8e78dc3bd6'),
('5cf8e78da670f', 'S Ramesh', '5cf8e78dc3fbe'),
('5cf8e78e15ea6', 'Arvind Saxena', '5cf8e78e1b880'),
('5cf8e78e15ea6', 'Sudha Jain ', '5cf8e78e1bc68'),
('5cf8e78e15ea6', 'Kirti Kumar ', '5cf8e78e1c050'),
('5cf8e78e15ea6', 'Omi Agrawal', '5cf8e78e1c438'),
('5cf8e78e3c7df', 'Jammu & Kashmir ', '5cf8e78e421b9'),
('5cf8e78e3c7df', 'Himachal Pradesh', '5cf8e78e425a1'),
('5cf8e78e3c7df', 'Uttarakhand ', '5cf8e78e42989'),
('5cf8e78e3c7df', 'Assam', '5cf8e78e42d71'),
('5cf8e78e5a476', 'Chennai', '5cf8e78e5eeaf'),
('5cf8e78e5a476', 'Delhi', '5cf8e78e5f297'),
('5cf8e78e5a476', 'Nagpur', '5cf8e78e5f67f'),
('5cf8e78e5a476', 'Kolkata', '5cf8e78e5fa67'),
('5cf8e78e80daf', 'Nittoor SrinivasaRau commiittee', '5cf8e78e85400'),
('5cf8e78e80daf', 'Tejendra Mohan Bhasin commiittee', '5cf8e78e857e8'),
('5cf8e78e80daf', 'KV Chowdary commiittee', '5cf8e78e85bd0'),
('5cf8e78e80daf', 'K Santhanam commiittee', '5cf8e78e85fb8'),
('5cf8e78e9d2d6', 'Union Bank of India', '5cf8e78ea2caf'),
('5cf8e78e9d2d6', 'Axis Bank', '5cf8e78ea3097'),
('5cf8e78e9d2d6', 'Punjab National Bank', '5cf8e78ea347f'),
('5cf8e78e9d2d6', 'Bank of Baroda', '5cf8e78ea3867'),
('5cf8e78eb9fcd', 'Fiji', '5cf8e78ebf9a6'),
('5cf8e78eb9fcd', 'Papua New Guinea', '5cf8e78ebfd8e'),
('5cf8e78eb9fcd', 'New Zealand', '5cf8e78ec0176'),
('5cf8e78eb9fcd', 'Marshall Islands', '5cf8e78ec055e'),
('5cf8e78ed64f3', 'Arjun Mitra', '5cf8e78edbecd'),
('5cf8e78ed64f3', 'Ashu Khullar', '5cf8e78edc2b5'),
('5cf8e78ed64f3', 'Nandish Prabhakar', '5cf8e78edc69d'),
('5cf8e78ed64f3', 'Rakesh Singh', '5cf8e78edca85'),
('5cf8e78f0071a', 'Andra Pradesh', '5cf8e78f060f4'),
('5cf8e78f0071a', 'Odisha', '5cf8e78f064dc'),
('5cf8e78f0071a', 'Rajasthan', '5cf8e78f068c4'),
('5cf8e78f0071a', 'Tamil Nadu', '5cf8e78f06cac'),
('5cf8e78f2ddb5', '2024', '5cf8e78f65c4a'),
('5cf8e78f2ddb5', '2022', '5cf8e78f66032'),
('5cf8e78f2ddb5', '2032', '5cf8e78f6641a'),
('5cf8e78f2ddb5', '2040', '5cf8e78f66802'),
('5cf8e78f89e73', 'K.N. Vyas', '5cf8e78f8f464'),
('5cf8e78f89e73', 'Dr. A.K. Mohanty', '5cf8e78f8f84c'),
('5cf8e78f89e73', 'Abhishek Agarwal', '5cf8e78f8fc34'),
('5cf8e78f89e73', 'Shatrughan Agrawal', '5cf8e78f9001c'),
('5cf8e78fadcb3', 'Dharmendra Pradhan', '5cf8e78fb2ad4'),
('5cf8e78fadcb3', 'Hardeep Singh Puri', '5cf8e78fb2ebc'),
('5cf8e78fadcb3', 'Piyush Goyal', '5cf8e78fb32a4'),
('5cf8e78fadcb3', 'Prakash Javadekar', '5cf8e78fb368c'),
('5cf8e7900ce8e', 'NASIK', '5cf8e7900d277'),
('5cf8e7900ce8e', ' NASIC', '5cf8e7900d65f'),
('5cf8e7900ce8e', 'NAVIC', '5cf8e7900da47'),
('5cf8e7900ce8e', 'NAVIK', '5cf8e7900de2f'),
('5cf8e790969cf', 'Chattisgarh', '5cf8e79096db7'),
('5cf8e790969cf', 'Telangana', '5cf8e7909719f'),
('5cf8e790969cf', 'Kerala', '5cf8e79097587'),
('5cf8e790969cf', 'Maharashtra', '5cf8e7909796f'),
('5cf8e790b9c57', 'Private Sector Banks', '5cf8e790ba03f'),
('5cf8e790b9c57', 'Public Sector Banks', '5cf8e790ba427'),
('5cf8e790b9c57', 'Regional Rural Banks', '5cf8e790ba80f'),
('5cf8e790b9c57', 'Cooperative Banks', '5cf8e790babf7'),
('5cf8e790d1745', 'Maharashtra', '5cf8e790dc327'),
('5cf8e790d1745', 'Madhya Pradesh', '5cf8e790dc70f'),
('5cf8e790d1745', 'Andhra Pradesh', '5cf8e790dcaf7'),
('5cf8e790d1745', 'Himachal Pradesh', '5cf8e790dcedf'),
('5cf8e790f1ed4', 'BTI Payments', '5cf8e790f22bc'),
('5cf8e790f1ed4', 'Tata Communications Payment Solutions', '5cf8e790f26a4'),
('5cf8e790f1ed4', 'Muthoot Finance Limited', '5cf8e790f2a8c'),
('5cf8e790f1ed4', 'Prize Payments Solutions Limited', '5cf8e790f2e74'),
('5cf8e791147e1', 'Darban, South Africa', '5cf8e7911a1bb'),
('5cf8e791147e1', 'London, UK', '5cf8e7911a5a3'),
('5cf8e791147e1', 'Toronto, Canada', '5cf8e7911a98b'),
('5cf8e791147e1', 'Gold Coast, Australia', '5cf8e7911ad73'),
('5cf8e791460e5', 'Russia', '5cf8e79148bde'),
('5cf8e791460e5', 'China', '5cf8e79148fc6'),
('5cf8e791460e5', ' France', '5cf8e791493ae'),
('5cf8e791460e5', 'USA', '5cf8e79149796'),
('5cf8e7915d7eb', 'Secret Super Star', '5cf8e791631c4'),
('5cf8e7915d7eb', 'Tumhari Sulu', '5cf8e791635ac'),
('5cf8e7915d7eb', ' Mom', '5cf8e79163994'),
('5cf8e7915d7eb', 'Hindi Medium', '5cf8e79163d7c');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('558921841f1ec', '558922117fcef', 'what is command for print in php??', 4, 1),
('558921841f1ec', '55892211e44d5', 'which is a variable of php??', 4, 2),
('5589222f16b93', '558922894c453', 'what is correct statement in c++??', 4, 1),
('5589222f16b93', '558922899ccaa', 'which command is use for print the output in c++?', 4, 2),
('558922ec03021', '558923538f48d', 'what is correct mask for A class IP???', 4, 1),
('558922ec03021', '55892353f05c4', 'which is not a private IP??', 4, 2),
('5cf8dd2dae8da', '5cf8e78788d09', 'Who has been appointed as the new chairman of Central Board of Indirect taxes and Customs (CBIC)?', 4, 1),
('5cf8dd2dae8da', '5cf8e788d53fc', 'Who has been appointed as the acting Chairman of the Union Public Service Commission (UPSC)?', 4, 2),
('5cf8dd2dae8da', '5cf8e7896e3ad', 'Pappu Karki, the popular Kumaoni folk singer has passed away. He was native of which state?', 4, 3),
('5cf8dd2dae8da', '5cf8e78a44bcc', 'Indiaâ€™s first-ever national police museum will establish in which city?', 4, 4),
('5cf8dd2dae8da', '5cf8e78aa85a4', 'The Central Vigilance Commission (CVC) is in news for appointing Sharad Kumar as new Vigilance Commissioner. As per which committeeâ€™s recommendations, the CVC was set up?', 4, 5),
('5cf8dd2dae8da', '5cf8e78aed344', 'Which bank has sanctioned a loan Rs 689 crore to over 1,600 Micro, Small and Medium Enterprises (MSMEs)?', 4, 6),
('5cf8dd2dae8da', '5cf8e78b36972', 'Which country is planning to release a digital currency called \"SOV\"?\r\n', 4, 7),
('5cf8dd2dae8da', '5cf8e78b55992', 'Who among the following has been appointed as the head of Citibank India?\r\n', 4, 8),
('5cf8dd2dae8da', '5cf8e78b7ca9b', 'Defence Research and Development Organization successfully test fired the PINAKA guided WEAPON rocket system which state?\r\n', 4, 9),
('5cf8dd2dae8da', '5cf8e78b9e99b', '5 Surat Metro Project springs up expected to serve the masses by __________.\r\n', 4, 10),
('5cf8dd2dae8da', '5cf8e78bcdb8e', 'Who among the following has taken charge as the Director of Bhabha Atomic Research Centre (BARC)?\r\n', 4, 11),
('5cf8dd2dae8da', '5cf8e78bf40df', 'Who launched the Indian Urban Observatory and Video wall at New Delhi?\r\n', 4, 12),
('5cf8dd2dae8da', '5cf8e78ca3fc5', 'Asian Infrastructure Investment Bank (AIIB) has recently approved a loan of USD 160 million for a power project in the Indian State of -\r\n', 4, 16),
('5cf8dd2dae8da', '5cf8e78cefeaf', 'Which of the following city is hosting the Commonwealth Game 2018?\r\n', 4, 18),
('5cf8dd2dae8da', '5cf8e78d18966', 'Which major world power quit the UNHRC ?\r\n', 4, 19),
('5cf8dd2dae8da', '5cf8e78d53eac', 'Which film was adjudged the â€˜Best Filmâ€™ in the 19th IIFA awards-2018 ?\r\n', 4, 20),
('5cf8dd2dae8da', '5cf8e78da670f', 'Who has been appointed as the new chairman of Central Board of Indirect taxes and Customs (CBIC)?', 4, 1),
('5cf8dd2dae8da', '5cf8e78e15ea6', 'Who has been appointed as the acting Chairman of the Union Public Service Commission (UPSC)?', 4, 2),
('5cf8dd2dae8da', '5cf8e78e3c7df', 'Pappu Karki, the popular Kumaoni folk singer has passed away. He was native of which state?', 4, 3),
('5cf8dd2dae8da', '5cf8e78e5a476', 'Indiaâ€™s first-ever national police museum will establish in which city?', 4, 4),
('5cf8dd2dae8da', '5cf8e78e80daf', 'The Central Vigilance Commission (CVC) is in news for appointing Sharad Kumar as new Vigilance Commissioner. As per which committeeâ€™s recommendations, the CVC was set up?', 4, 5),
('5cf8dd2dae8da', '5cf8e78e9d2d6', 'Which bank has sanctioned a loan Rs 689 crore to over 1,600 Micro, Small and Medium Enterprises (MSMEs)?', 4, 6),
('5cf8dd2dae8da', '5cf8e78eb9fcd', 'Which country is planning to release a digital currency called \"SOV\"?\r\n', 4, 7),
('5cf8dd2dae8da', '5cf8e78ed64f3', 'Who among the following has been appointed as the head of Citibank India?\r\n', 4, 8),
('5cf8dd2dae8da', '5cf8e78f0071a', 'Defence Research and Development Organization successfully test fired the PINAKA guided WEAPON rocket system which state?\r\n', 4, 9),
('5cf8dd2dae8da', '5cf8e78f2ddb5', '5 Surat Metro Project springs up expected to serve the masses by __________.\r\n', 4, 10),
('5cf8dd2dae8da', '5cf8e78f89e73', 'Who among the following has taken charge as the Director of Bhabha Atomic Research Centre (BARC)?\r\n', 4, 11),
('5cf8dd2dae8da', '5cf8e78fadcb3', 'Who launched the Indian Urban Observatory and Video wall at New Delhi?\r\n', 4, 12),
('5cf8dd2dae8da', '5cf8e790d1745', 'Asian Infrastructure Investment Bank (AIIB) has recently approved a loan of USD 160 million for a power project in the Indian State of -\r\n', 4, 16),
('5cf8dd2dae8da', '5cf8e791147e1', 'Which of the following city is hosting the Commonwealth Game 2018?\r\n', 4, 18),
('5cf8dd2dae8da', '5cf8e791460e5', 'Which major world power quit the UNHRC ?\r\n', 4, 19),
('5cf8dd2dae8da', '5cf8e7915d7eb', 'Which film was adjudged the â€˜Best Filmâ€™ in the 19th IIFA awards-2018 ?\r\n', 4, 20);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `time`, `intro`, `tag`, `date`) VALUES
('558921841f1ec', 'Php Coding', 2, 1, 2, 5, '', 'PHP', '2015-06-23 09:06:12'),
('5589222f16b93', 'C++ Coding', 2, 1, 2, 5, '', 'c++', '2015-06-23 09:09:03'),
('558922ec03021', 'Networking', 2, 1, 2, 5, '', 'networking', '2015-06-23 09:12:12'),
('5cf8dd2dae8da', 'C2c', 2, 2, 20, 30, '', '#C2C', '2019-06-06 09:30:21');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('saiushajosyula@gmail.com', -16, '2019-06-06 10:20:26'),
('kiransai8811@gmail.com', -12, '2019-06-06 10:55:43'),
('sairam@gmail.com', -16, '2019-06-06 10:57:35');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Sai Kiran Kasireddy', 'M', 'Vspt', 'kiransai8811@gmail.com', 9966663721, 'c44a471bd78cc6c2fea32b9fe028d30a'),
('Sai Ram', 'M', 'dvn college', 'sairam@gmail.com', 8985080725, '25f9e794323b453885f5181f1b624d0b'),
('Usha', 'F', 'dvn college', 'saiushajosyula@gmail.com', 9030375530, '44fc4237d3028c25c7bb23e0e8301402');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
